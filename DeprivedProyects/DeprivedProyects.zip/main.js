// ============================================
// DeprivedProyects — main.js
// ============================================

// ---- NAV HAMBURGER ----
const hamburger = document.getElementById('hamburger');
const navLinks = document.querySelector('.nav-links');

if (hamburger && navLinks) {
  hamburger.addEventListener('click', () => {
    navLinks.classList.toggle('open');
  });

  // Cerrar al hacer click en un link
  navLinks.querySelectorAll('a').forEach(link => {
    link.addEventListener('click', () => {
      navLinks.classList.remove('open');
    });
  });
}

// ---- NAV SCROLL EFFECT ----
const nav = document.querySelector('nav');
window.addEventListener('scroll', () => {
  if (window.scrollY > 40) {
    nav.style.borderBottomColor = 'rgba(255,68,34,0.2)';
  } else {
    nav.style.borderBottomColor = 'var(--border)';
  }
});

// ---- CONTACT FORM ----
const form = document.getElementById('contact-form');
if (form) {
  form.addEventListener('submit', (e) => {
    e.preventDefault();

    const btn = form.querySelector('button[type="submit"]');
    const original = btn.textContent;

    btn.textContent = 'ENVIANDO...';
    btn.style.opacity = '0.6';
    btn.disabled = true;

    // Aquí conectas tu backend, Formspree, EmailJS, etc.
    // Ejemplo con Formspree:
    // fetch('https://formspree.io/f/TU_ID', { method: 'POST', body: new FormData(form) })

    setTimeout(() => {
      btn.textContent = '✓ MENSAJE ENVIADO';
      btn.style.background = '#22c55e';
      btn.style.opacity = '1';
      form.reset();

      setTimeout(() => {
        btn.textContent = original;
        btn.style.background = 'var(--orange)';
        btn.disabled = false;
      }, 4000);
    }, 1200);
  });
}

// ---- SCROLL REVEAL ----
const observer = new IntersectionObserver((entries) => {
  entries.forEach(entry => {
    if (entry.isIntersecting) {
      entry.target.style.opacity = '1';
      entry.target.style.transform = 'translateY(0)';
    }
  });
}, { threshold: 0.1 });

document.querySelectorAll('.service-card, .step, .price-card').forEach(el => {
  el.style.opacity = '0';
  el.style.transform = 'translateY(20px)';
  el.style.transition = 'opacity 0.5s ease, transform 0.5s ease';
  observer.observe(el);
});
